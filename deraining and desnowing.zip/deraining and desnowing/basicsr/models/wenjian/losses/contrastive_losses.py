import torch
import torch.nn as nn
import torch.nn.functional as F

class PatchNCELoss(nn.Module):
    def forward(self, x, x_hat, encoder):
        # Simplified: patch encoder usage skipped
        return F.l1_loss(x, x_hat)  # placeholder for PatchNCE

class PatchCorrelationLoss(nn.Module):
    def __init__(self, temperature=0.07, patch_num=16, patch_size=32, feat_dim=512):
        super().__init__()
        self.temperature = temperature
        self.patch_num = patch_num
        self.patch_size = patch_size

        # MLP projector assumes input is from encoder, not raw RGB!
        self.projector = nn.Sequential(
            nn.Linear(feat_dim, 256),
            nn.ReLU(inplace=True),
            nn.Linear(256, 128)
        )

    def extract_patches(self, feat_map):
        # feat_map: [B, C, H, W]
        B, C, H, W = feat_map.size()
        patches = []

        for _ in range(self.patch_num):
            top = torch.randint(0, H - self.patch_size + 1, (1,)).item()
            left = torch.randint(0, W - self.patch_size + 1, (1,)).item()
            patch = feat_map[:, :, top:top + self.patch_size, left:left + self.patch_size]  # [B, C, p, p]
            patch = F.adaptive_avg_pool2d(patch, (1, 1)).view(B, C)  # flatten to [B, C]
            patches.append(patch)

        return torch.cat(patches, dim=0)  # [B * N, C]

    def forward(self, x, x_hat, encoder):
        # Step 1: extract features from encoder
        feat_q = encoder(x)      # [B, C, H, W]
        feat_k = encoder(x_hat)  # [B, C, H, W]

        # Step 2: random patches → [BN, C]
        q = self.extract_patches(feat_q)  # [BN, C]
        k = self.extract_patches(feat_k)  # [BN, C]

        # Step 3: project → normalize
        q = F.normalize(self.projector(q), dim=1)  # [BN, D]
        k = F.normalize(self.projector(k), dim=1)  # [BN, D]

        # Step 4: contrastive loss
        logits = torch.matmul(q, k.T) / self.temperature
        labels = torch.arange(logits.shape[0], device=logits.device)
        return F.cross_entropy(logits, labels)

class CategoryContrastiveLoss(nn.Module):
    def forward(self, z1, z2, z3, stage='cfp'):
        if stage == 'cfp':
            pos = torch.exp((z1 * z1).sum(dim=1) / 0.07)
            neg = torch.exp((z1 * z2).sum(dim=1) / 0.07)
        else:
            pos = torch.exp((z1 * z2).sum(dim=1) / 0.07)
            neg = torch.exp((z1 * z3).sum(dim=1) / 0.07)
        return -torch.log(pos / (pos + neg)).mean()