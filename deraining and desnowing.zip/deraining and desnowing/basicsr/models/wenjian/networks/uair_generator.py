import torch
import torch.nn as nn

class ResidualDenseBlock(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.conv1 = nn.Conv2d(channels, channels, 3, padding=1)
        self.conv2 = nn.Conv2d(channels, channels, 3, padding=1)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        return x + self.conv2(self.relu(self.conv1(x)))

class Generator(nn.Module):
    def __init__(self, in_channels=3, out_channels=3, num_feat=64, num_blocks=5):
        super().__init__()
        self.head = nn.Conv2d(in_channels, num_feat, 3, padding=1)
        self.rdbs = nn.Sequential(*[ResidualDenseBlock(num_feat) for _ in range(num_blocks)])
        self.tail = nn.Conv2d(num_feat, out_channels, 3, padding=1)

    def forward(self, x):
        identity = x
        x = self.head(x)
        x = self.rdbs(x)
        x = self.tail(x)
        return torch.tanh(identity + x)