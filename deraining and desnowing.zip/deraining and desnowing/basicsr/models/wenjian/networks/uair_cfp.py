import torch
import torch.nn as nn
import torch.nn.functional as F

class ContrastiveProjector(nn.Module):
    def __init__(self, in_dim=256, out_dim=128):  # 修改为和 Discriminator encoder 输出对齐
        super().__init__()
        self.projector = nn.Sequential(
            nn.Linear(in_dim, out_dim),
            nn.ReLU(True),
            nn.Linear(out_dim, out_dim)
        )

    def forward(self, x):
        # x: [B, C, H, W]
        x = F.adaptive_avg_pool2d(x, 1).flatten(1)
        return F.normalize(self.projector(x), dim=1)
