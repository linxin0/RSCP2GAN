import datetime
import logging
import math
import time
import torch
from os import path as osp
from basicsr.data import build_dataloader, build_dataset
from basicsr.data.data_sampler import EnlargedSampler
from basicsr.data.prefetch_dataloader import CUDAPrefetcher
from basicsr.models import build_model
from basicsr.utils import (AvgTimer, MessageLogger, check_resume, get_env_info, get_root_logger, get_time_str,
                           init_tb_logger, init_wandb_logger, make_exp_dirs, mkdir_and_rename, scandir)
from basicsr.utils.options import copy_opt_file, dict2str, parse_options

def init_tb_loggers(opt):
    if opt['logger'].get('wandb') and opt['logger']['wandb'].get('project') and 'debug' not in opt['name']:
        assert opt['logger'].get('use_tb_logger') is True
        init_wandb_logger(opt)
    tb_logger = None
    if opt['logger'].get('use_tb_logger') and 'debug' not in opt['name']:
        tb_logger = init_tb_logger(log_dir=osp.join(opt['root_path'], 'tb_logger', opt['name']))
    return tb_logger

def create_train_val_dataloader(opt, logger):
    dataset_enlarge_ratio = opt['datasets']['train1'].get('dataset_enlarge_ratio', 1)
    train_set1 = build_dataset(opt['datasets']['train1'])
    train_sampler1 = EnlargedSampler(train_set1, opt['world_size'], opt['rank'], dataset_enlarge_ratio)
    train_loader1 = build_dataloader(train_set1, opt['datasets']['train1'], opt['num_gpu'], opt['dist'], None, seed=opt['manual_seed'])

    train_set2 = build_dataset(opt['datasets']['train2'])
    train_sampler2 = EnlargedSampler(train_set2, opt['world_size'], opt['rank'], dataset_enlarge_ratio)
    train_loader2 = build_dataloader(train_set2, opt['datasets']['train2'], opt['num_gpu'], opt['dist'], None, seed=opt['manual_seed'])

    num_iter_per_epoch = math.ceil(len(train_set1) * dataset_enlarge_ratio / (opt['datasets']['train1']['batch_size_per_gpu'] * opt['world_size']))
    total_iters = int(opt['train']['total_iter'])
    total_epochs = math.ceil(total_iters / num_iter_per_epoch)

    logger.info(f'Training stats:\n\t#images: {len(train_set1)},\n\tBatch: {opt["datasets"]["train1"]["batch_size_per_gpu"]},\n\tEpochs: {total_epochs},\n\tIters: {total_iters}')
    return train_loader1, train_sampler1, train_loader2, train_sampler2, total_epochs, total_iters

def load_resume_state(opt):
    resume_state_path = opt['path'].get('resume_state', None)
    if resume_state_path:
        device_id = torch.cuda.current_device()
        resume_state = torch.load(resume_state_path, map_location=lambda storage, loc: storage.cuda(device_id))
        check_resume(opt, resume_state['iter'])
        return resume_state
    return None

def train_pipeline(root_path):
    opt, args = parse_options(root_path, is_train=True)
    opt['root_path'] = root_path
    torch.backends.cudnn.benchmark = True

    resume_state = load_resume_state(opt)
    if resume_state is None:
        make_exp_dirs(opt)
        if opt['logger'].get('use_tb_logger') and 'debug' not in opt['name'] and opt['rank'] == 0:
            mkdir_and_rename(osp.join(opt['root_path'], 'tb_logger', opt['name']))

    copy_opt_file(args.opt, opt['path']['experiments_root'])
    logger = get_root_logger('basicsr', logging.INFO, osp.join(opt['path']['log'], f"train_{opt['name']}_{get_time_str()}.log"))
    logger.info(get_env_info())
    logger.info(dict2str(opt))
    tb_logger = init_tb_loggers(opt)

    train_loader1, train_sampler1, train_loader2, train_sampler2, total_epochs, total_iters = create_train_val_dataloader(opt, logger)
    model = build_model(opt)
    start_epoch, current_iter = (resume_state['epoch'], resume_state['iter']) if resume_state else (1, 1)
    if resume_state:
        model.resume_training(resume_state)
        logger.info(f"Resuming from epoch {start_epoch}, iter {current_iter}")

    msg_logger = MessageLogger(opt, current_iter, tb_logger)
    prefetcher1 = CUDAPrefetcher(train_loader1, opt)
    prefetcher2 = CUDAPrefetcher(train_loader2, opt)

    logger.info(f'Start training from epoch {start_epoch}, iter {current_iter}')
    data_timer, iter_timer = AvgTimer(), AvgTimer()
    start_time = time.time()

    for epoch in range(start_epoch, total_epochs + 1):
        train_sampler1.set_epoch(epoch)
        train_sampler2.set_epoch(epoch)
        prefetcher1.reset()
        prefetcher2.reset()
        train_data1 = prefetcher1.next()
        train_data2 = prefetcher2.next()

        while train_data1 is not None:
            data_timer.record()
            current_iter += 1
            if current_iter > total_iters:
                break
            model.update_learning_rate(current_iter, warmup_iter=opt['train'].get('warmup_iter', -1))
            model.feed_data(train_data1, train_data2)
            model.optimize_parameters(current_iter)
            iter_timer.record()

            if current_iter == 1:
                msg_logger.reset_start_time()

            if current_iter % opt['logger']['print_freq'] == 0:
                log_vars = {'epoch': epoch, 'iter': current_iter}
                log_vars.update({'lrs': model.get_current_learning_rate()})
                log_vars.update({'time': iter_timer.get_avg_time(), 'data_time': data_timer.get_avg_time()})
                log_vars.update(model.get_current_log())
                msg_logger(log_vars)

            if current_iter % opt['logger']['save_checkpoint_freq'] == 0:
                logger.info('Saving models and states.')
                model.save(epoch, current_iter)

            data_timer.start()
            iter_timer.start()
            train_data1 = prefetcher1.next()
            train_data2 = prefetcher2.next()
            if current_iter % 10000 == 0:
                model.ceshi()
    logger.info(f'Training finished. Time consumed: {str(datetime.timedelta(seconds=int(time.time() - start_time)))}')
    logger.info('Saving latest model.')
    model.save(epoch=-1, current_iter=-1)
    if tb_logger:
        tb_logger.close()

if __name__ == '__main__':
    root_path = osp.abspath(osp.join(__file__, osp.pardir, osp.pardir))
    train_pipeline(root_path)
