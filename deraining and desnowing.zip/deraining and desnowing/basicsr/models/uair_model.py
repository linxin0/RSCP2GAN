import torch
from torch import nn
from basicsr.models.base_model import BaseModel
from basicsr.utils.registry import MODEL_REGISTRY
from .networks import define_generator, define_discriminator, define_projector
from .losses import PatchNCELoss, PatchCorrelationLoss, CategoryContrastiveLoss
from basicsr.utils import get_root_logger, tensor2img
from torchvision import transforms
import os, math, cv2
import numpy as np
from PIL import Image
import torch.nn.functional as F

@MODEL_REGISTRY.register()
class UAIRModel(BaseModel):
    def __init__(self, opt):
        super().__init__(opt)
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.net_g = define_generator(opt['network_g']).to(self.device)
        self.net_d = define_discriminator(opt['network_d']).to(self.device)
        self.cfp = define_projector(opt['cfp']).to(self.device)

        self.loss_idt = nn.L1Loss().to(self.device)
        self.loss_adv = nn.MSELoss().to(self.device)
        self.loss_nce = PatchNCELoss().to(self.device)
        self.loss_pcc = PatchCorrelationLoss().to(self.device)
        self.loss_cat = CategoryContrastiveLoss().to(self.device)

        def get_optim(optim_cfg, params):
            optim_cfg = optim_cfg.copy()
            optim_type = optim_cfg.pop('type')
            return getattr(torch.optim, optim_type)(params, **optim_cfg)

        self.optim_g = get_optim(opt['train']['optim_g'], self.net_g.parameters())
        self.optim_d = get_optim(opt['train']['optim_d'], self.net_d.parameters())
        self.optim_cfp = get_optim(opt['train']['optim_cfp'], self.cfp.parameters())

        self.log_dict = {}

    def feed_data(self, data1, data2):
        self.degraded = data1['lq'].to(self.device)
        self.clean = data2['gt'].to(self.device)

    def optimize_parameters(self, current_iter):
        # === Phase 1: Train CFP ===
        self.net_d.eval()
        self.net_g.eval()
        self.cfp.train()
        self.optim_cfp.zero_grad()

        # with torch.no_grad():
        #     feat_clean = self.net_d.extract_features(self.clean)
        #     feat_degraded = self.net_d.extract_features(self.degraded)
        # z_clean = self.cfp(feat_clean.to(self.device))
        # z_degraded = self.cfp(feat_degraded.to(self.device))
        # loss_cfp = self.loss_cat(z_clean, z_degraded, None, stage='cfp')
        # loss_cfp.backward()

        # === Phase 2: Train Generator ===
        self.net_d.eval()
        self.cfp.eval()
        self.net_g.train()
        self.optim_g.zero_grad()

        feat_degraded_g, self.restored = self.net_g(self.degraded)
        _, clean_gene = self.net_g(self.clean)
        feat_res,_ = self.net_g(self.restored)

        dis_clean,_ = self.net_d(self.clean)
        dis_degr,_ = self.net_d(self.degraded)
        dis_res,_ = self.net_d(self.restored)
        # print(dis_clean.shape)
        # 256 32 32
        cfp_clean = self.cfp(dis_clean)
        cfp_degr = self.cfp(dis_degr)
        cfp_res = self.cfp(dis_res)
        # print(cfp_clean.shape)
        loss_id = self.loss_idt(clean_gene, self.clean)
        # print(self.clean.shape)
        loss_adv = self.loss_adv(self.net_d(self.restored)[1], torch.ones_like(self.net_d(self.clean)[1]))
        loss_nce = self.loss_cat(cfp_res, cfp_clean, cfp_degr)
        loss_pcc = self.loss_pcc(feat_degraded_g, feat_res)

        # with torch.no_grad():
        #     feat_clean_2 = self.net_d.extract_features(self.clean)
        #     feat_degraded_2 = self.net_d.extract_features(self.degraded)
        #     z_clean_2 = self.cfp(feat_clean_2.to(self.device))
        #     z_degraded_2 = self.cfp(feat_degraded_2.to(self.device))
        #     feat_restored = self.net_d.extract_features(self.restored)
        #     z_restored = self.cfp(feat_restored.to(self.device))
        #
        # loss_catg = self.loss_cat(z_restored, z_clean_2, z_degraded_2, stage='gen')

        total_loss = loss_adv + 2.0 * loss_id + loss_nce + 0.02* loss_pcc
        total_loss.backward()
        self.optim_g.step()
        self.optim_cfp.step()


        # === Phase 3: Train Discriminator ===
        self.net_d.train()
        for p in self.net_d.parameters():
            p.requires_grad = True
        self.optim_d.zero_grad()

        # fake = torch.tanh(self.degraded + self.restored.detach())
        real_d_pred = self.net_d(self.clean)[1]
        fake_d_pred = self.net_d(self.restored.detach())[1]

        l_d_real = torch.mean(real_d_pred ** 2)
        l_d_fake = torch.mean((1 - fake_d_pred) ** 2)
        l_d_total = 0.5 * (l_d_real + l_d_fake)
        l_d_total.backward(retain_graph=True)
        self.optim_d.step()

        self.log_dict = {
            'loss_id': loss_id.item(), 'loss_adv': loss_adv.item(),
            'loss_nce': loss_nce.item(), 'loss_pcc': loss_pcc.item(),
            'l_d_real': l_d_real.item(), 'l_d_fake': l_d_fake.item(), 'l_d_total': l_d_total.item()
        }

    def get_current_log(self):
        return self.log_dict

    def get_current_learning_rate(self):
        return [group['lr'] for group in self.optim_g.param_groups]

    def save(self, epoch, current_iter):
        self.save_network(self.net_g, 'net_g', current_iter, self.opt['path']['models'])
        self.save_network(self.net_d, 'net_d', current_iter, self.opt['path']['models'])

    def ceshi(self):
        print("Start evaluation (ceshi)...")
        net_g = nn.DataParallel(self.net_g).cuda()
        net_g.eval()
        tf = transforms.ToTensor()

        img_dir = 'data_snow/CSD/Test/Snow'
        gt_dir = 'data_snow/CSD/Test/Gt'
        save_dir = './ceshi_results'
        os.makedirs(save_dir, exist_ok=True)

        file_list = sorted(os.listdir(img_dir))
        total_psnr = 0
        for fname in file_list:
            img = tf(Image.open(os.path.join(img_dir, fname)).convert('RGB')).unsqueeze(0).cuda()
            gt = tf(Image.open(os.path.join(gt_dir, fname)).convert('RGB')).unsqueeze(0).cuda()

            with torch.no_grad():
                B,C,H,W = img.shape
                h_pad = (H // 16 + 1) * 16 - H
                w_pad = (W // 16 + 1) * 16 - W
                img_pad = F.pad(img, (0, w_pad, 0, h_pad), mode='reflect')
                pred = net_g(img_pad)[1][:, :, :H, :W]
            pred_img = (pred.squeeze(0).cpu().clamp(0, 1).numpy().transpose(1,2,0) * 255).astype(np.uint8)
            cv2.imwrite(os.path.join(save_dir, fname), cv2.cvtColor(pred_img, cv2.COLOR_RGB2BGR))

            mse = F.mse_loss(pred, gt).item()
            psnr = 20 * math.log10(1.0 / math.sqrt(mse))
            total_psnr += psnr

        avg_psnr = total_psnr / len(file_list)
        print(f'Avg PSNR over {len(file_list)} images: {avg_psnr:.2f} dB')