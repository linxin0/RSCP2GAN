import torch
import torch.nn as nn
import torch.nn.functional as F
import random

class PatchNCELoss(nn.Module):
    def forward(self, x, x_hat, encoder):
        return F.l1_loss(x, x_hat)  # placeholder


import torch
import torch.nn as nn
import torch.nn.functional as F
import random

class PatchCorrelationLoss(nn.Module):
    def __init__(self, temperature=0.07):
        super().__init__()
        self.temperature = temperature

    def forward(self, feat_q, feat_k):  # [B, C, H, W]
        B, C, H, W = feat_q.shape
        N = 4  # 采样 4 个 patch
        device = feat_q.device

        # 随机采样 4 个相同位置的 patch 坐标
        patch_coords = [(random.randint(0, H-1), random.randint(0, W-1)) for _ in range(N)]

        # 提取对应 patch: [B, N, C]
        def sample(feat):
            patches = []
            for h, w in patch_coords:
                patch = feat[:, :, h, w]  # [B, C]
                patches.append(patch)
            return torch.stack(patches, dim=1)  # [B, N, C]

        feat_q_patches = sample(feat_q)  # degraded
        feat_k_patches = sample(feat_k)  # restored

        # 展平为 M 个 query 和 key：[M, C], 其中 M = B*N
        M = B * N
        feat_q_flat = F.normalize(feat_q_patches.reshape(M, C), dim=1)
        feat_k_flat = F.normalize(feat_k_patches.reshape(M, C), dim=1)

        # 计算所有相似度 [M, M]
        logits = torch.matmul(feat_q_flat, feat_k_flat.T) / self.temperature  # [M, M]
        labels = torch.arange(M, device=device)

        # PatchNCE loss: 仅使用同 index 的匹配项为 positive
        loss = F.cross_entropy(logits, labels)

        return loss



class CategoryContrastiveLoss(nn.Module):
    def forward(self, z1, z2, z3):
        # if stage == 'cfp':
        #     pos = torch.exp((z1 * z1).sum(dim=1) / 0.07)
        #     neg = torch.exp((z1 * z2).sum(dim=1) / 0.07)
        # else:
        pos = torch.exp((z1 * z2).sum(dim=1) / 0.07)
        neg = torch.exp((z1 * z3).sum(dim=1) / 0.07)

        return -torch.log(pos / (pos + neg)).mean()
