import torch
import torch.nn as nn
import torch.nn.functional as F


class ResidualDenseBlock(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.conv1 = nn.Conv2d(channels, channels, 3, padding=1)
        self.conv2 = nn.Conv2d(channels, channels, 3, padding=1)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        return x + self.conv2(self.relu(self.conv1(x)))


import torch
import torch.nn as nn
import torch.nn.functional as F

class ResidualDenseBlock(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, 3, padding=1)
        )

    def forward(self, x):
        return x + self.block(x)

class Generator(nn.Module):
    def __init__(self, in_channels=3, out_channels=3, num_feat=64):
        super().__init__()

        # initial conv layers
        self.conv1 = nn.Sequential(
            nn.Conv2d(in_channels, num_feat, 3, padding=1),
            nn.ReLU(inplace=True)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(num_feat, num_feat, 3, padding=1),
            nn.ReLU(inplace=True)
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(num_feat, num_feat, 3, padding=1),
            nn.ReLU(inplace=True)
        )

        # RDB + Conv+Sigmoid
        def rdb_block():
            return nn.Sequential(
                ResidualDenseBlock(num_feat),
                nn.Conv2d(num_feat, num_feat, 3, padding=1),
                nn.Sigmoid()
            )

        self.rdb1 = rdb_block()
        self.rdb2 = nn.Sequential(
            nn.Conv2d(num_feat, num_feat, 3, padding=1),
            nn.ReLU(inplace=True),
            ResidualDenseBlock(num_feat),
            nn.Conv2d(num_feat, num_feat, 3, padding=1),
            nn.Sigmoid()
        )
        self.rdb3 = ResidualDenseBlock(num_feat)

        # Decoder
        self.deconv1 = nn.ConvTranspose2d(num_feat, num_feat, 3, stride=1, padding=1)
        self.deconv2 = nn.ConvTranspose2d(num_feat, num_feat, 3, stride=1, padding=1)

        self.conv_out = nn.Sequential(
            nn.Conv2d(num_feat, num_feat, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(num_feat, out_channels, 3, padding=1)
        )

    def forward(self, x):
        residual = x
        x = self.conv1(x)
        x1 = self.conv2(x)
        skip = self.conv3(x1)

        x = self.rdb1(skip)
        x = self.rdb2(x)
        x = self.rdb3(x)

        x = self.deconv1(x)
        x = self.deconv2(x+skip)
        x = self.conv_out(x1+x)

        out = torch.tanh(x + residual)  # final tanh + residual connection
        return skip, out

# class Generator(nn.Module):
#     def __init__(self, in_channels=3, out_channels=3, num_feat=64, num_blocks=5, proj_dim=256):
#         super().__init__()
#         self.head = nn.Conv2d(in_channels, num_feat, 3, padding=1)
#         self.rdbs = nn.Sequential(*[ResidualDenseBlock(num_feat) for _ in range(num_blocks)])
#         self.tail = nn.Conv2d(num_feat, out_channels, 3, padding=1)
#
#         # Add projector MLP (used by PatchCorrelationLoss)
#         self.projector = nn.Sequential(
#             nn.Linear(num_feat * 8 * 8, proj_dim),  # assume patches are 8x8 after flatten
#             nn.ReLU(inplace=True),
#             nn.Linear(proj_dim, proj_dim)
#         )
#
#     def forward(self, x):
#         identity = x
#         feat = self.head(x)
#         feat = self.rdbs(feat)
#
#
#         out = self.tail(feat)
#         return feat, torch.tanh(identity + out)
