from .uair_generator import Generator
from .uair_discriminator import Discriminator
from .uair_cfp import ContrastiveProjector



def define_generator(opt):
    opt = {k: v for k, v in opt.items() if k != 'type'}
    return Generator(**opt)

def define_discriminator(opt):
    opt = {k: v for k, v in opt.items() if k != 'type'}
    return Discriminator(**opt)

def define_projector(opt):
    opt = {k: v for k, v in opt.items() if k != 'type'}
    return ContrastiveProjector(**opt)