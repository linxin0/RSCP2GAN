import torch.nn as nn

class Discriminator(nn.Module):
    def __init__(self, in_channels=3):
        super().__init__()
        nf = 64
        self.encoder = nn.Sequential(
            nn.Conv2d(in_channels, nf, 3, 1, 1), nn.ReLU(True),
            nn.Conv2d(nf, nf, 3, 2, 1), nn.ReLU(True),
            nn.Conv2d(nf, nf*2, 3, 1, 1), nn.ReLU(True),
            nn.Conv2d(nf*2, nf*2, 3, 2, 1), nn.ReLU(True),
            nn.Conv2d(nf*2, nf*4, 3, 1, 1), nn.ReLU(True),
            nn.Conv2d(nf*4, nf*4, 3, 2, 1), nn.ReLU(True)
        )
        self.classifier = nn.Conv2d(nf*4, 1, 3, padding=1)

    def forward(self, x):
        feat = self.encoder(x)
        return feat, self.classifier(feat)

    def extract_features(self, x):
        return self.encoder(x)
