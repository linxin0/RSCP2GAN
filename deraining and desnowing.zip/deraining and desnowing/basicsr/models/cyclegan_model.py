import torch
from collections import OrderedDict
from os import path as osp
from tqdm import tqdm
import torch

import torch.distributed
gpus = ','.join([str(i) for i in [0,1]])

# torch.distributed.init_process_group(backend="nccl")
import os
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = gpus
import torch.nn as nn
from basicsr.archs import build_network
from basicsr.losses import build_loss
from basicsr.metrics import calculate_metric
from basicsr.utils import get_root_logger, imwrite, tensor2img
from basicsr.utils.registry import MODEL_REGISTRY
from .base_model import BaseModel
import cv2
import kornia.utils as KU
import os
import time
from PIL import Image
import math
import numpy as np
from torchvision.transforms import transforms
img_path = '/media/sr617/29b9171f-dba6-4703-98a5-43495a4a4fe6/Basicsr_unspervised/basicsr/data/test/input'
targeet_path = '/media/sr617/29b9171f-dba6-4703-98a5-43495a4a4fe6/Basicsr_unspervised/basicsr/data/test/target'

img_list = sorted(os.listdir(img_path))
num_img = len(img_list)
from torchvision.transforms.functional import rotate,vflip
import random

def data_augmentation(image, mode):
    '''
    Performs dat augmentation of the input image
    Input:
        image: a cv2 (OpenCV) image
        mode: int. Choice of transformation to apply to the image

       0 - no transformation
                1 - flip up and down
                2 - rotate counterwise 90 degree
                3 - rotate 90 degree and flip up and down
                4 - rotate 180 degree
                5 - rotate 180 degree and flip
                6 - rotate 270 degree
                7 - rotate 270 degree and flip
    '''
    if mode == 0:
        # original
        out = image
    elif mode == 1:
        # flip up and down
        out = vflip(image)
    elif mode == 2:
        # rotate counterwise 90 degree
        out = rotate(image,90)
    elif mode == 3:
        # rotate 90 degree and flip up and down
        out = rotate(image,90)
        out = vflip(out)
    elif mode == 4:
        # rotate 180 degree
        out = rotate(image,180)
    elif mode == 5:
        # rotate 180 degree and flip
        out = rotate(image,180)
        out = vflip(out)
    elif mode == 6:
        # rotate 270 degree
        out = rotate(image,270)
    elif mode == 7:
        # rotate 270 degree and flip
        out = rotate(image,270)
        out = vflip(out)
    else:
        raise Exception('Invalid choice of image transformation')

    return out
def psnr(pred, gt):

    pred = pred.clamp(0, 1).cpu().numpy()
    gt = gt.clamp(0, 1).cpu().numpy()
    imdff = pred - gt
    rmse = math.sqrt(np.mean(imdff ** 2))
    if rmse == 0:
        return 100
    return 20 * math.log10(1.0 / rmse)
def redata_augmentation(image, mode):
    '''
    Performs dat augmentation of the input image
    Input:
        image: a cv2 (OpenCV) image
        mode: int. Choice of transformation to apply to the image
                0 - no transformation
                1 - flip up and down
                2 - rotate counterwise 90 degree
                3 - rotate 90 degree and flip up and down
                4 - rotate 180 degree
                5 - rotate 180 degree and flip
                6 - rotate 270 degree
                7 - rotate 270 degree and flip
    '''
    if mode == 0:
        # original
        out = image
    elif mode == 1:
        # flip up and down
        out = vflip(image)
    elif mode == 2:
        # rotate counterwise 90 degree
        out = rotate(image,270)
    elif mode == 3:
        # rotate 90 degree and flip up and down
        out = vflip(image)
        out = rotate(out,270)
        # out = vflip(out)
    elif mode == 4:
        # rotate 180 degree
        out = rotate(image,180)
    elif mode == 5:
        # rotate 180 degree and flip
        out= rotate(image,180)
        out = vflip(out)
    elif mode == 6:
        # rotate 270 degree
        out = rotate(image,90)
    elif mode == 7:
        # rotate 270 degree and flip
        out = vflip(image)
        out = rotate(out,90)

    else:
        raise Exception('Invalid choice of image transformation')

    return out

def imsave(img, filename):
    img = img.squeeze().cpu()
    img = KU.tensor_to_image(img) * 255.
    cv2.imwrite(filename, cv2.cvtColor(img, cv2.COLOR_RGB2BGR))


class FrequencyLoss(nn.Module):
    def __init__(self):
        super(FrequencyLoss, self).__init__()

    def forward(self, x, target):
        b, c, h, w = x.size()
        x = x.contiguous().view(-1, h, w)
        target = target.contiguous().view(-1, h, w)
        x_fft = torch.rfft(x, signal_ndim=2, normalized=False, onesided=True)
        target_fft = torch.rfft(target, signal_ndim=2, normalized=False, onesided=True)

        _, h, w, f = x_fft.size()
        x_fft = x_fft.view(b, c, h, w, f)
        target_fft = target_fft.view(b, c, h, w, f)
        diff = x_fft - target_fft
        return torch.mean(torch.sum(diff ** 2, (1, 2, 3, 4)))

@MODEL_REGISTRY.register()
class CycleganModel(BaseModel):
    """Base SR model for single image super-resolution."""

    def __init__(self, opt):
        super(CycleganModel, self).__init__(opt)

        # define network
        self.net_ir = build_network(opt['network_ir'])
        self.net_ir = self.model_to_device(self.net_ir)
        # self.print_network(self.net_ir)



        self.net_g = build_network(opt['network_g'])
        self.net_g = self.model_to_device(self.net_g)
        # self.print_network(self.net_g)

        self.net_d_ir = build_network(opt['network_d_ir'])
        self.net_d_ir = self.model_to_device(self.net_d_ir)
        # self.print_network(self.net_d)

        self.net_d_g = build_network(opt['network_d_g'])
        self.net_d_g = self.model_to_device(self.net_d_g)
        # self.print_network(self.net_d)

        # load pretrained models
        load_path1 = self.opt['path'].get('pretrain_network_ir', None)
        if load_path1 is not None:
            param_key = self.opt['path'].get('param_key_ir', 'params')
            self.load_network(self.net_ir, load_path1, self.opt['path'].get('strict_load_ir', True), param_key)

        load_path2 = self.opt['path'].get('pretrain_network_g', None)
        if load_path2 is not None:
            param_key = self.opt['path'].get('param_key_g', 'params')
            self.load_network(self.net_g, load_path2, self.opt['path'].get('strict_load_g', True), param_key)

        load_path3 = self.opt['path'].get('pretrain_network_d', None)
        if load_path3 is not None:
            param_key = self.opt['path'].get('param_key_d', 'params')
            self.load_network(self.net_d, load_path3, self.opt['path'].get('strict_load_d', True), param_key)
        if self.is_train:
            self.init_training_settings()

    def init_training_settings(self):
        self.net_ir.train()
        self.net_g.train()
        self.net_d_ir.train()
        self.net_d_g.train()

        train_opt = self.opt['train']

        self.ema_decay = train_opt.get('ema_decay', 0)
        if self.ema_decay > 0:
            logger = get_root_logger()
            logger.info(f'Use Exponential Moving Average with decay: {self.ema_decay}')
            # define network net_g with Exponential Moving Average (EMA)
            # net_g_ema is used only for testing on one GPU and saving
            # There is no need to wrap with DistributedDataParallel
            self.net_ir_ema = build_network(self.opt['network_ir']).to(self.device)
            self.net_g_ema = build_network(self.opt['network_g']).to(self.device)
            # load pretrained model
            load_path1 = self.opt['path'].get('pretrain_network_ir', None)
            load_path2 = self.opt['path'].get('pretrain_network_g', None)
            if load_path1 is not None:
                self.load_network(self.net_ir_ema, load_path1, self.opt['path'].get('strict_load_ir', True), 'params_ema')
            else:
                self.model_ema(0)  # copy net_g weight

            if load_path2 is not None:
                self.load_network(self.net_g_ema, load_path2, self.opt['path'].get('strict_load_g', True), 'params_ema')
            else:
                self.model_ema(0)  # copy net_g weight

            self.net_g_ema.eval()
            self.net_ir_ema.eval()

        # define losses
        L2 = nn.MSELoss().cuda()
        L1 = nn.L1Loss().cuda()
        self.criterionIdt = torch.nn.L1Loss().to(self.device)
        self.criterionL1 = torch.nn.L1Loss().to(self.device)
        self.criterionFrequency = FrequencyLoss()

        self.l2 = L2
        self.l1 = L1
        if train_opt.get('pixel_opt'):
            self.cri_pix = build_loss(train_opt['pixel_opt']).to(self.device)
        else:
            self.cri_pix = None

        if train_opt.get('perceptual_opt'):
            self.cri_perceptual = build_loss(train_opt['perceptual_opt']).to(self.device)
        else:
            self.cri_perceptual = None

        if train_opt.get('bgm_opt'):
            self.cri_bgm = build_loss(train_opt['bgm_opt']).to(self.device)
        else:
            self.cri_bgm = None

        if train_opt.get('gan_opt'):
            self.cri_gan = build_loss(train_opt['gan_opt']).to(self.device)

        if train_opt.get('ssim_opt'):
            self.cri_ssim = build_loss(train_opt['ssim_opt']).to(self.device)
        else:
            self.cri_ssim = None

        self.net_d_iters = train_opt.get('net_d_iters', 1)
        self.net_d_init_iters = train_opt.get('net_d_init_iters', 0)
        # set up optimizers and schedulers
        self.setup_optimizers()
        self.setup_schedulers()

    def setup_optimizers(self):
        train_opt = self.opt['train']
        optim_params = []
        for k, v in self.net_g.named_parameters():
            if v.requires_grad:
                optim_params.append(v)
            else:
                logger = get_root_logger()
                logger.warning(f'Params {k} will not be optimized.')

        optim_type = train_opt['optim_ir'].pop('type')
        self.optimizer_ir = self.get_optimizer(optim_type, self.net_ir.parameters(), **train_opt['optim_ir'])
        self.optimizers.append(self.optimizer_ir)

        optim_type = train_opt['optim_g'].pop('type')
        self.optimizer_g = self.get_optimizer(optim_type, optim_params, **train_opt['optim_g'])
        self.optimizers.append(self.optimizer_g)

        optim_type = train_opt['optim_d_ir'].pop('type')
        self.optimizer_d_ir = self.get_optimizer(optim_type, self.net_d_ir.parameters(), **train_opt['optim_d_ir'])
        self.optimizers.append(self.optimizer_d)

        optim_type = train_opt['optim_d_g'].pop('type')
        self.optimizer_d_g = self.get_optimizer(optim_type, self.net_d_g.parameters(), **train_opt['optim_d_g'])
        self.optimizers.append(self.optimizer_d)

    def feed_data(self, data1, data2):
        self.lq = data1['lq'].to(self.device)
        if 'gt' in data2:
            self.gt = data2['gt'].to(self.device)

    def feed_val_data(self, data):
        self.lq = data['lq'].to(self.device)
        if 'gt' in data:
            self.gt = data['gt'].to(self.device)

    def optimize_parameters(self, current_iter):
        # optimize net_g
        for p in self.net_d_ir.parameters():
            p.requires_grad = False
        for p in self.net_d_g.parameters():
            p.requires_grad = False
        self.optimizer_g.zero_grad()
        self.optimizer_ir.zero_grad()
        # self.output = self.net_g(self.lq, self.gt)
        real_lr_A = self.lq
        real_hr_B = self.gt


        #LR和HR融合以后输入到生成器中
        y_rec = self.net_ir(real_lr_A.detach())
        y_s_syn = self.net_g(y_rec)
        x_u_syn = self.net_g(real_hr_B)
        x_rec = self.net_ir(x_u_syn.detach())



        l_g_total = 0
        l_ir_total = 0
        loss_dict = OrderedDict()
        if (current_iter % self.net_d_iters == 0 and current_iter > self.net_d_init_iters):
            # pixel loss
            if self.cri_pix:
                l_ir_pix = self.cri_pix(x_rec, real_hr_B)
                l_ir_total += l_ir_pix
                loss_dict['l_ir_pix'] = l_ir_pix

            if self.cri_ssim:
                l_ir_ssim= self.cri_ssim(x_rec, real_hr_B)
                l_ir_total += l_ir_ssim
                loss_dict['l_ir_ssim'] = l_ir_ssim


            self.fake_B_red = x_rec[:, 0:1, :, :]
            self.fake_B_green = x_rec[:, 1:2, :, :]
            self.fake_B_blue = x_rec[:, 2:3, :, :]

            self.real_B_red = real_hr_B[:, 0:1, :, :]
            self.real_B_green = real_hr_B[:, 1:2, :, :]
            self.real_B_blue = real_hr_B[:, 2:3, :, :]

            self.fake_A_red = y_s_syn[:, 0:1, :, :]
            self.fake_A_green = y_s_syn[:, 1:2, :, :]
            self.fake_A_blue = y_s_syn[:, 2:3, :, :]

            self.real_A_red = real_lr_A[:, 0:1, :, :]
            self.real_A_green = real_lr_A[:, 1:2, :, :]
            self.real_A_blue = real_lr_A[:, 2:3, :, :]


            # gan loss
            adversarial_loss1 = self.cri_gan(self.net_d_g(y_s_syn), True)
            adversarial_loss2 = self.cri_gan(self.net_d_g(x_u_syn), True)
            cycle_loss = self.l2(real_lr_A, y_s_syn)
            fu = self.criterionFrequency(real_lr_A, y_s_syn)
            color_cycle = self.l1(self.fake_A_red, self.real_A_red) + self.l1(self.fake_A_green, self.real_A_green)+ self.l1(self.fake_A_blue, self.real_A_blue)
            l_g_gan = adversarial_loss1 + adversarial_loss2 + cycle_loss * 2 + color_cycle + color_cycle + fu*0.1
            l_g_total += l_g_gan

            color_cycle_ir = self.l1(self.fake_B_red, self.real_B_red) + self.l1(self.fake_B_green, self.real_B_green)+ self.l1(self.fake_B_blue, self.real_B_blue)
            fu_ir = self.criterionFrequency(x_rec, real_hr_B)
            adversarial_loss1_ir = self.cri_gan(self.net_d_ir(x_rec), True)
            adversarial_loss2_ir = self.cri_gan(self.net_d_ir(y_rec), True)
            l_ir_total += adversarial_loss1_ir + adversarial_loss2_ir + fu_ir * 0.1 + color_cycle_ir * 2
            loss_dict['l_g_gan'] = l_g_gan

            l_g_total.backward(retain_graph=True)
            l_ir_total.backward(retain_graph=True)
            self.optimizer_g.step()
            self.optimizer_ir.step()

        # optimize net_d
        for p in self.net_d_ir.parameters():
            p.requires_grad = True
        for p in self.net_d_g.parameters():
            p.requires_grad = True
        self.optimizer_d_ir.zero_grad()
        self.optimizer_d_g.zero_grad()

        # real
        real_d_g_pred = self.net_d_g(real_lr_A)
        l_d_g_real = self.cri_gan(real_d_g_pred, True)

        real_d_ir_pred = self.net_d_ir(real_hr_B)
        l_d_ir_real = self.cri_gan(real_d_ir_pred, True)

        loss_dict['l_d_real'] = l_d_g_real + l_d_ir_real
        loss_dict['out_d_real'] = torch.mean(real_d_g_pred.detach()) + torch.mean(real_d_ir_pred.detach())
        l_d_real = l_d_g_real + l_d_ir_real
        l_d_real.backward()

        fake_d_g_pred_1 = self.net_d_g(x_u_syn.detach())
        l_d_fake_1 = self.cri_gan(fake_d_g_pred_1, False)

        fake_d_ir_pred_1 = self.net_d_g(x_rec.detach())
        l_d_ir_fake_1 = self.cri_gan(fake_d_ir_pred_1, False)

        l_d_fake = l_d_fake_1 + l_d_ir_fake_1
        loss_dict['l_d_fake'] = l_d_fake
        loss_dict['out_d_fake'] = torch.mean(fake_d_g_pred_1.detach()) + torch.mean(l_d_ir_fake_1.detach())
        l_d_fake.backward()
        self.optimizer_d_g.step()
        self.optimizer_d_ir.step()

        self.log_dict = self.reduce_loss_dict(loss_dict)

        if self.ema_decay > 0:
            self.model_ema(decay=self.ema_decay)

    def test(self):
        if hasattr(self, 'net_ir_ema'):
            self.net_ir_ema.eval()
            with torch.no_grad():
                self.output = self.net_ir_ema(self.lq)
        else:
            self.net_ir.eval()
            with torch.no_grad():
                self.output = self.net_ir(self.lq)
            self.net_ir.train()

    def test_selfensemble(self):
        # TODO: to be tested
        # 8 augmentations
        # modified from https://github.com/thstkdgus35/EDSR-PyTorch

        def _transform(v, op):
            # if self.precision != 'single': v = v.float()
            v2np = v.data.cpu().numpy()
            if op == 'v':
                tfnp = v2np[:, :, :, ::-1].copy()
            elif op == 'h':
                tfnp = v2np[:, :, ::-1, :].copy()
            elif op == 't':
                tfnp = v2np.transpose((0, 1, 3, 2)).copy()

            ret = torch.Tensor(tfnp).to(self.device)
            # if self.precision == 'half': ret = ret.half()

            return ret

        # prepare augmented data
        lq_list = [self.lq]
        for tf in 'v', 'h', 't':
            lq_list.extend([_transform(t, tf) for t in lq_list])

        # inference
        if hasattr(self, 'net_ir_ema'):
            self.net_ir_ema.eval()
            with torch.no_grad():
                out_list = [self.net_ir_ema(aug) for aug in lq_list]
        else:
            self.net_ir.eval()
            with torch.no_grad():
                out_list = [self.net_ir_ema(aug) for aug in lq_list]
            self.net_ir.train()

        # merge results
        for i in range(len(out_list)):
            if i > 3:
                out_list[i] = _transform(out_list[i], 't')
            if i % 4 > 1:
                out_list[i] = _transform(out_list[i], 'h')
            if (i % 4) % 2 == 1:
                out_list[i] = _transform(out_list[i], 'v')
        output = torch.cat(out_list, dim=0)

        self.output = output.mean(dim=0, keepdim=True)

    def dist_validation(self, dataloader, current_iter, tb_logger, save_img):
        if self.opt['rank'] == 0:
            self.nondist_validation(dataloader, current_iter, tb_logger, save_img)

    def nondist_validation(self, dataloader, current_iter, tb_logger, save_img):
        dataset_name = dataloader.dataset.opt['name']
        with_metrics = self.opt['val'].get('metrics') is not None
        use_pbar = self.opt['val'].get('pbar', False)

        if with_metrics:
            if not hasattr(self, 'metric_results'):  # only execute in the first run
                self.metric_results = {metric: 0 for metric in self.opt['val']['metrics'].keys()}
            # initialize the best metric results for each dataset_name (supporting multiple validation datasets)
            self._initialize_best_metric_results(dataset_name)
        # zero self.metric_results
        if with_metrics:
            self.metric_results = {metric: 0 for metric in self.metric_results}

        metric_data = dict()
        if use_pbar:
            pbar = tqdm(total=len(dataloader), unit='image')

        for idx, val_data in enumerate(dataloader):
            img_name = osp.splitext(osp.basename(val_data['lq_path'][0]))[0]
            self.feed_val_data(val_data)
            self.test()

            visuals = self.get_current_visuals()
            sr_img = tensor2img([visuals['result']])
            metric_data['img'] = sr_img
            if 'gt' in visuals:
                gt_img = tensor2img([visuals['gt']])
                metric_data['img2'] = gt_img
                del self.gt

            # tentative for out of GPU memory
            del self.lq
            del self.output
            torch.cuda.empty_cache()

            if save_img:
                if self.opt['is_train']:
                    save_img_path = osp.join(self.opt['path']['visualization'], img_name,
                                             f'{img_name}_{current_iter}.png')
                else:
                    if self.opt['val']['suffix']:
                        save_img_path = osp.join(self.opt['path']['visualization'], dataset_name,
                                                 f'{img_name}_{self.opt["val"]["suffix"]}.png')
                    else:
                        save_img_path = osp.join(self.opt['path']['visualization'], dataset_name,
                                                 f'{img_name}_{self.opt["name"]}.png')
                imwrite(sr_img, save_img_path)

            if with_metrics:
                # calculate metrics
                for name, opt_ in self.opt['val']['metrics'].items():
                    self.metric_results[name] += calculate_metric(metric_data, opt_)
            if use_pbar:
                pbar.update(1)
                pbar.set_description(f'Test {img_name}')
        if use_pbar:
            pbar.close()

        if with_metrics:
            for metric in self.metric_results.keys():
                self.metric_results[metric] /= (idx + 1)
                # update the best metric result
                self._update_best_metric_result(dataset_name, metric, self.metric_results[metric], current_iter)

            self._log_validation_metric_values(current_iter, dataset_name, tb_logger)

    def _log_validation_metric_values(self, current_iter, dataset_name, tb_logger):
        log_str = f'Validation {dataset_name}\n'
        for metric, value in self.metric_results.items():
            log_str += f'\t # {metric}: {value:.4f}'
            if hasattr(self, 'best_metric_results'):
                log_str += (f'\tBest: {self.best_metric_results[dataset_name][metric]["val"]:.4f} @ '
                            f'{self.best_metric_results[dataset_name][metric]["iter"]} iter')
            log_str += '\n'

        logger = get_root_logger()
        logger.info(log_str)
        if tb_logger:
            for metric, value in self.metric_results.items():
                tb_logger.add_scalar(f'metrics/{dataset_name}/{metric}', value, current_iter)

    def get_current_visuals(self):
        out_dict = OrderedDict()
        out_dict['lq'] = self.lq.detach().cpu()
        out_dict['result'] = self.output.detach().cpu()
        if hasattr(self, 'gt'):
            out_dict['gt'] = self.gt.detach().cpu()
        return out_dict

    def ceshi(self):
        print("laileao")
        device_ids = [i for i in range(torch.cuda.device_count())]
        net_ir = nn.DataParallel(self.net_ir, device_ids=device_ids)
        net_ir.cuda()
        net_ir.eval()
        transform = transforms.ToTensor()
        PSNR = 0
        for img in img_list:
            # print(img)
            image = Image.open(img_path + '/' + img).convert('RGB')
            target = Image.open(targeet_path + '/' + img).convert('RGB')
            image = transform(image)
            target = transform(target)
            image = image.cuda()
            target = target.cuda()
            [A, B, C] = image.shape
            image = image.reshape([1, A, B, C])
            [A, B, C] = target.shape
            target = target.reshape([1, A, B, C])
            with torch.set_grad_enabled(False):
                B,C,H,W = image.size()
                _, _, h_old, w_old = image.size()
                h_pad = (h_old // 16 + 1) * 16 - h_old
                w_pad = (w_old // 16+ 1) * 16 - w_old
                img_lq = torch.cat([image, torch.flip(image, [2])], 2)[:, :, :h_old + h_pad, :]
                img_lq = torch.cat([img_lq, torch.flip(img_lq, [3])], 3)[:, :, :, :w_old + w_pad]
                pre = net_ir(img_lq)
                pre= pre[:,:,:H,:W]
            psnr_out = psnr(pre, target)
            PSNR += psnr_out
        print("PSNR =", PSNR / num_img)

    def save(self, epoch, current_iter):
        if hasattr(self, 'net_ir_ema'):
            self.save_network([self.net_ir, self.net_ir_ema], 'net_ir', current_iter, param_key=['params', 'params_ema'])
        else:
            self.save_network(self.net_ir, 'net_ir', current_iter)
        if hasattr(self, 'net_g_ema'):
            self.save_network([self.net_g, self.net_g_ema], 'net_g', current_iter, param_key=['params', 'params_ema'])
        else:
            self.save_network(self.net_g, 'net_g', current_iter)
        self.save_network(self.net_d, 'net_d', current_iter)
        # self.save_training_state(epoch, current_iter)