import yaml
import torch
from PIL import Image
from torch import nn
from Model.kernal_estimation.model.MANet_arch import MANet_s1
import Model.kernal_estimation.model.util as util
import os
import numpy as np

class DegradationModel(nn.Module):
    def __init__(self, kernel_size=15, scale=4, sv_degradation=True):
        super(DegradationModel, self).__init__()
        if sv_degradation:
            self.blur_layer = util.BatchBlur_SV(l=kernel_size, padmode='replication')
            self.sample_layer = util.BatchSubsample(scale=scale)
        else:
            self.blur_layer = util.BatchBlur(l=kernel_size, padmode='replication')
            self.sample_layer = util.BatchSubsample(scale=scale)

    def forward(self, image, kernel):
        return self.sample_layer(self.blur_layer(image, kernel))

def is_image_file(filename):
    return any(filename.endswith(extension) for extension in IMG_EXTENSIONS)

IMG_EXTENSIONS = ['.jpg', '.JPG', '.jpeg', '.JPEG', '.png', '.PNG', '.ppm', '.PPM', '.bmp', '.BMP', '.tif']


def np2tensor(self, imgs):
    return torch.from_numpy(imgs.astype(np.float32) / 255.).float().permute(2, 0, 1)

def tensor2img(img_tensor):
    """
    Input image tensor shape must be [B C H W]
    the return image numpy array shape is [B H W C]
    """
    res = img_tensor.numpy()
    # res = (res + 1.0) / 2.0
    res = np.clip(res, 0.0, 1.0)
    res = res * 255
    res = res.transpose((0,2,3,1))
    return res

path = 'yml/test_stage1.yml'
with open(path, 'r') as f:
    opt = yaml.full_load(f)
opt_net = opt['network_G']

netG = MANet_s1(in_nc=opt_net['in_nc'], out_nc=opt_net['out_nc'],
                                   nf=opt_net['nf'], nb=opt_net['nb'], gc=opt_net['gc'],
                                   scale=opt['scale'], code_length=opt['code_length'],
                                   kernel_size=opt['kernel_size'],
                                   manet_nf=opt_net['manet_nf'], manet_nb=opt_net['manet_nb'], split=opt_net['split'])

load_net = torch.load(opt['path']['pretrain_model_K'])
netG.load_state_dict(load_net)

hr = (rf'E:\clf\code\version\kernal-Estimation\img\gt\gt2.png')
lr = (rf'E:\clf\code\version\kernal-Estimation\img\lr\lr2.png')
img_gt = np.array(Image.open(hr), dtype=np.uint8)
img_lq = np.array(Image.open(lr), dtype=np.uint8)

img_gt = (torch.from_numpy(img_gt) / 255.).float().permute(2, 0, 1)
img_lq = (torch.from_numpy(img_lq) / 255.).float().permute(2, 0, 1)

img_gt = img_gt.unsqueeze(0)
img_lq = img_lq.unsqueeze(0)
print(img_gt.shape)
print(img_lq.shape)

# img_gt, img_lq = np2tensor(img_gt), np2tensor(img_lq)



fake_SR, fake_K = netG(img_lq, opt['kernel_size'])

degradation_model = DegradationModel(opt['kernel_size'], opt['scale'], sv_degradation=True)
fake_LR = degradation_model(img_gt, fake_K)
# 将图片打印出来
img_1 = tensor2img(fake_LR.detach().cpu())
image = Image.fromarray(np.uint8(img_1[0])).convert('RGB')
image.save('img/lr/fake_lr_3.png')





