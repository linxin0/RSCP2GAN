

def model_import(model_name, args):

    if model_name == 'DDDAN_16':
        from Model.DDDAN import MetaNeXt
        model = MetaNeXt(scale=args.scale_factor, stage=16)

    elif model_name == 'MIRNet':
        from Model.mirnet_v2_arch import MIRNet_v2
        model = MIRNet_v2(scale=args.scale_factor)

    elif model_name == 'UFP':
        # from Model.image_restoration_model import ImageRestorationModel
        # model = ImageRestorationModel(args.yml)
        from Model.archs.UFPNet_code_uncertainty_arch import UFPNet_code_uncertainty_Local as net
        model = net(width=64, enc_blk_nums=[1, 1, 1, 28], middle_blk_num=1, dec_blk_nums=[1, 1, 1, 1])

    elif model_name == 'NAF':
        # from Model.image_restoration_model import ImageRestorationModel
        # model = ImageRestorationModel(args.yml)
        from Model.archs.NAFNet_arch import NAFNetLocal
        model = NAFNetLocal(width=64, enc_blk_nums=[1, 1, 1, 28], middle_blk_num=1, dec_blk_nums=[1, 1, 1, 1])
    elif model_name == 'Stripformer':
        from Model.Stripformer import Stripformer
        model = Stripformer()
    elif model_name == 'OmniSR':
        from Model.OmniSR import OmniSR
        model = OmniSR(**args.yml["module_params"])
    elif model_name == 'FCL':
        from Model.fcl_gan import BUM
        model = BUM()


    return model


