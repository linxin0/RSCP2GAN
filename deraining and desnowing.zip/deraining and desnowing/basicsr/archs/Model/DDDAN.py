from functools import partial
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange
from torchvision.io import read_image

from Model.Transformer_Block import to_2tuple, trunc_normal_, DropPath



class eca_layer(nn.Module):
    """Constructs a ECA module.
    Args:
        channel: Number of channels of the input feature map
        k_size: Adaptive selection of kernel size
    """
    def __init__(self, channel, gamma=2, b=1, k_size=3):
        super(eca_layer, self).__init__()
        t = int(abs((math.log(channel, 2) + b) / gamma))
        k = t if t % 2 else t + 1
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=k, padding=(k - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # x: input features with shape [b, c, h, w]
        b, c, h, w = x.size()
        # feature descriptor on the global spatial information
        y = self.avg_pool(x)
        # Two different branches of ECA module
        y = self.conv(y.squeeze(-1).transpose(-1, -2)).transpose(-1, -2).unsqueeze(-1)
        # Multi-scale information fusion
        y = self.sigmoid(y)
        return x * y  #.expand_as(x)


class CALayer(nn.Module):
    def __init__(self, channel, reduction=16):
        super(CALayer, self).__init__()
        # global average pooling: feature --> point
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # feature channel downscale and upscale --> channel weight
        self.conv_du = nn.Sequential(
                nn.Conv2d(channel, channel // reduction, 1, padding=0, bias=True),
                nn.GELU(),#nn.ReLU(inplace=True),
                nn.Conv2d(channel // reduction, channel, 1, padding=0, bias=True),
                nn.Sigmoid()
        )

    def forward(self, x):
        y = self.avg_pool(x)
        y = self.conv_du(y)
        return x * y


class LayerNorm(nn.Module):
    r""" LayerNorm that supports two data formats: channels_last (default) or channels_first.
    The ordering of the dimensions in the inputs. channels_last corresponds to inputs with
    shape (batch_size, height, width, channels) while channels_first corresponds to inputs
    with shape (batch_size, channels, height, width).
    """

    def __init__(self,
                 normalized_shape,
                 eps=1e-6,
                 data_format="channels_first"):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.eps = eps
        self.data_format = data_format
        assert self.data_format in ["channels_last", "channels_first"]
        self.normalized_shape = (normalized_shape,)

    def forward(self, x):
        if self.data_format == "channels_last":
            return F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)
        elif self.data_format == "channels_first":
            u = x.mean(1, keepdim=True)
            s = (x - u).pow(2).mean(1, keepdim=True)
            x = (x - u) / torch.sqrt(s + self.eps)
            x = self.weight[:, None, None] * x + self.bias[:, None, None]
            return x


class DSA(nn.Module):
    def __init__(self, in_channels, shuffle=True, square_kernel_size=3, band_kernel_size=11, branch_ratio=0.25): #0.125
        super(DSA, self).__init__()

        gc = int(in_channels * branch_ratio)  # channel numbers of a convolution branch
        self.dwconv_hw = nn.Conv2d(gc, gc, square_kernel_size, padding=square_kernel_size // 2, groups=gc)
        self.dwconv_w = nn.Conv2d(gc, gc, kernel_size=(1, band_kernel_size), padding=(0, band_kernel_size // 2),
                                  groups=gc)
        self.dwconv_h = nn.Conv2d(gc, gc, kernel_size=(band_kernel_size, 1), padding=(band_kernel_size // 2, 0),
                                  groups=gc)
        self.split_indexes = (in_channels - 3 * gc, gc, gc, gc)
        self.conv_act = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, 1),
            nn.SiLU(True)
        )
        self.shuffle = shuffle

    def forward(self, x):
        x_id, x_hw, x_w, x_h = torch.split(x, self.split_indexes, dim=1)
        out = self.conv_act(torch.cat((x_id, self.dwconv_hw(x_hw), self.dwconv_w(x_w), self.dwconv_h(x_h)), dim=1)) * x
        if self.shuffle:
            return rearrange(out, 'b (g d) h w -> b (d g) h w', g=64)
        else:
            return out


class FeedForward(nn.Module):
    """https://github.com/swz30/Restormer/blob/main/basicsr/models/archs/restormer_arch.py"""
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(FeedForward, self).__init__()

        hidden_features = int(dim*ffn_expansion_factor)
        self.project_in_ = nn.Conv2d(dim, hidden_features*2, kernel_size=1, bias=bias)
        self.dwconv_ = nn.Conv2d(hidden_features*2, hidden_features*2, kernel_size=3, stride=1, padding=1, groups=hidden_features*2, bias=bias)
        self.project_out_ = nn.Conv2d(hidden_features, dim, kernel_size=1, bias=bias)
        self.attn = BiAttn(dim)
        # self.ca = eca(dim)

    def forward(self, x):
        x = self.project_in_(x)
        x1, x2 = self.dwconv_(x).chunk(2, dim=1)
        x = F.gelu(x1) * x2 #self.ca(x2)
        x = self.project_out_(x)
        x = self.attn(x)
        return x


class BiAttn(nn.Module):
    def __init__(self, in_channels, act_ratio=0.25, act_fn=nn.GELU, gate_fn=nn.Sigmoid):
        super().__init__()
        reduce_channels = int(in_channels * act_ratio)
        self.norm = LayerNorm(in_channels, data_format='channels_first')
        self.global_reduce = nn.Conv2d(in_channels, reduce_channels, 1) #Linear(in_channels, reduce_channels)
        self.local_reduce = nn.Conv2d(in_channels, reduce_channels, 1)
        self.act_fn = act_fn()
        self.channel_select = nn.Conv2d(reduce_channels, in_channels, 1)
        self.spatial_select = nn.Conv2d(reduce_channels * 2, 1, 1)
        self.gate_fn = gate_fn()

    def forward(self, x):
        """
        :param x: [B, C, H, W]
        :return: [B, C, H, W]
        """
        ori_x = x
        b,c,h,w=x.shape
        x = self.norm(x)
        x_global = F.adaptive_avg_pool2d(x, 1) #x.mean(1, keepdim=True)   # [B, C, 1, 1]
        x_global = self.act_fn(self.global_reduce(x_global))   # [B, C/4, 1, 1]
        x_local = self.act_fn(self.local_reduce(x))   # [B, C/4, H, W]

        c_attn = self.channel_select(x_global)  # [B, C, 1, 1]
        c_attn = self.gate_fn(c_attn)  # [B, C, 1, 1]

        # temp = torch.ones((b, int(c/4), h, w), dtype=x_global.dtype, device=x_global.device) * x_global
        s_attn = self.spatial_select(torch.cat([x_local, x_global.expand(b, x_global.shape[1], x.shape[2], x.shape[3])], dim=1))  #(torch.cat([x_local, temp], dim=1)) #) #.expand(-1, x.shape[1], -1)
        s_attn = self.gate_fn(s_attn)  # [B, 1, H, W]

        attn = c_attn * s_attn  # [B, N, C]
        return ori_x * attn


class DCA(nn.Module):
    def __init__(self, in_features, mlp_ratio=4, act_layer=nn.GELU, drop=0.):
        super(DCA, self).__init__()
        # out_features = out_features or in_features
        hidden_features = int(in_features * mlp_ratio) #hidden_features or in_features
        self.fc1_ = nn.Conv2d(in_features, hidden_features, 1)
        self.dwconv_ = nn.Conv2d(hidden_features,hidden_features,3,1,1,groups=hidden_features)#DWConv(hidden_features)
        self.act_ = act_layer()
        self.fc2_ = nn.Conv2d(hidden_features, in_features, 1)
        self.drop_ = nn.Dropout(drop)

        self.ca = BiAttn(in_features) #CALayer(hidden_features, reduction=8) #eca_layer(hidden_features) #

    def forward(self, x):
        '''
        self.ca(x) * idn : 37.9384

        '''
        # idn = x
        x = self.fc1_(x)
        x = self.dwconv_(x)

        x = self.act_(x)
        x = self.drop_(x)
        x = self.fc2_(x)
        x = self.drop_(x)
        x = self.ca(x)  #* x
        return x


class CCM(nn.Module):
    def __init__(self, dim, growth_rate=2.0):
        super().__init__()
        hidden_dim = int(dim * growth_rate)

        self.ccm = nn.Sequential(
            nn.Conv2d(dim, hidden_dim, 3, 1, 1),
            nn.GELU(),
            nn.Conv2d(hidden_dim, dim, 1, 1, 0)
        )

    def forward(self, x):
        return self.ccm(x)


class ConvMlp(nn.Module):
    """ MLP using 1x1 convs that keeps spatial dims
    copied from timm: https://github.com/huggingface/pytorch-image-models/blob/v0.6.11/timm/models/layers/mlp.py
    """

    def __init__(
            self, in_features, hidden_features=None, out_features=None, act_layer=nn.ReLU,
            norm_layer=None, bias=True, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        bias = to_2tuple(bias)

        self.fc1 = nn.Conv2d(in_features, hidden_features, kernel_size=1, bias=bias[0])
        self.norm = norm_layer(hidden_features) if norm_layer else nn.Identity()
        self.act = act_layer()
        self.drop = nn.Dropout(drop)
        self.fc2 = nn.Conv2d(hidden_features, out_features, kernel_size=1, bias=bias[1])

    def forward(self, x):
        x = self.fc1(x)
        x = self.norm(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        return x


class MetaNeXtBlock(nn.Module):
    """ MetaNeXtBlock Block
    Args:
        dim (int): Number of input channels.
        drop_path (float): Stochastic depth rate. Default: 0.0
        ls_init_value (float): Init value for Layer Scale. Default: 1e-6.
    """

    def __init__(
            self,
            dim,
            token_mixer=DSA,
            norm_layer=nn.BatchNorm2d,
            mlp_layer=DCA,
            mlp_ratio=4,
            act_layer=nn.GELU,
            ls_init_value=1e-6,
            drop_path=0.,
    ):
        super().__init__()
        self.token_mixer = token_mixer(dim)
        self.norm = norm_layer(dim)
        self.mlp = DCA(dim, 2) #CCM(dim,2) #FeedForward(dim,2.66,True) #mlp_layer(dim, int(mlp_ratio * dim), act_layer=act_layer)
        self.gamma = nn.Parameter(ls_init_value * torch.ones(dim)) if ls_init_value else None
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

    def forward(self, x):
        shortcut = x
        x = self.token_mixer(x)
        x = self.norm(x)
        x = self.mlp(x)
        if self.gamma is not None:
            x = x.mul(self.gamma.reshape(1, x.shape[1], 1, 1))
        x = self.drop_path(x) + shortcut
        return x


class MetaNeXt(nn.Module):
    def __init__(
            self,
            depths=1,#(3, 3, 9, 3),
            stage=16,
            embed_dims=64,
            scale=2,
            token_mixer=DSA,
            norm_layer=nn.BatchNorm2d,
            mlp_layer=DCA,
            mlp_ratio=2,#(4, 4, 4, 3)
            act_layer=nn.GELU,
            ls_init_value=1e-6,
            drop_path=0.,
            drop_rate=0.,
            drop_path_rate=0.,
            **kwargs,
    ):
        super().__init__()
        # num_stage = len(depths)
        # if not isinstance(token_mixers, (list, tuple)):
        #     token_mixers = [token_mixers] * num_stage
        # if not isinstance(mlp_ratios, (list, tuple)):
        #     mlp_ratios = [mlp_ratios] * num_stage

        self.head = nn.Sequential(
            nn.Conv2d(3, embed_dims, 3, 1, 1),
        )
        self.tail = nn.Sequential(
            nn.Conv2d(embed_dims, 3 * scale * scale, 3, 1, 1),
            nn.PixelShuffle(scale),
        )

        self.stages = nn.Sequential()
        stages = []
        for i in range(stage):
            stages.append(MetaNeXtBlock(
                dim=embed_dims,
                token_mixer=token_mixer,
                norm_layer=norm_layer,
                mlp_layer=mlp_layer,
                mlp_ratio=mlp_ratio,
                act_layer=act_layer,
                ls_init_value=ls_init_value,
                drop_path=drop_path
            ))
        self.stages = nn.Sequential(*stages)
        self.apply(self._init_weights)

        # for name, param in self.named_parameters():
        #     # print(name, param.shape)
        #     if name.split(".")[0] == 'tail': # tail.0.weight torch.Size([12, 64, 3, 3])
        #         param.requires_grad = True
        #     else:
        #         param.requires_grad = False


    def forward(self, x):
        x = self.head(x)
        x = self.stages(x) + x
        x = self.tail(x)
        return x

    def _init_weights(self, m):
        if isinstance(m, (nn.Conv2d, nn.Linear)):
            trunc_normal_(m.weight, std=.02)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)


if __name__ == '__main__':
    from Metrics.ntire.model_summary import get_model_flops, get_model_activation
    from Metrics.flops_compute import compute_flops

    scale = 4  # 16: 0.4260M/87.9280G (38.1248)  | 15: 0.3999M/82.5570G (38.1273)  |  14: 0.3739M/77.1859G (38.10)
    # 16: eca: 0.3728/83.5633  |  0.3815/37.9646  |  0.3936/22.0852
    # 15: eca: 0.3501/78.4650  |  0.3587/35.7022  |  0.3708/20.8106
    # 14: eca: 0.3273/73.3667  |  0.3360/33.4398  |  0.3481/19.5361
    model = MetaNeXt(scale=scale, stage=1).cuda()
    h,w = 720//scale, 1280//scale
    x = torch.randn((1, 3, h, w)).cuda()
    # for name, param in model.named_parameters():
    #     if param.requires_grad:
    #         print(name, param.shape)

    with torch.no_grad():
        # out = model(x)
        # print(out.shape)

        input_dim = (3, h, w)  # set the input dimension
        activations, num_conv = get_model_activation(model, input_dim)
        activations = activations / 10 ** 6
        print("{:>16s} : {:<.4f} [M]".format("#Activations", activations))
        print("{:>16s} : {:<d}".format("#Conv2d", num_conv))

        flops = get_model_flops(model, input_dim, False)
        flops = flops / 10 ** 9
        print("{:>16s} : {:<.4f} [G]".format("FLOPs", flops))
    #
        num_parameters = sum(map(lambda x: x.numel(), model.parameters()))
        num_parameters = num_parameters / 10 ** 6
        print("{:>16s} : {:<.4f} [M]".format("#Params", num_parameters))

        print(f'{num_parameters}M/{flops}G')
    #
        # flopps = compute_flops(model,x)
        # print(flopps)


'''
x2 | x3 | x4:
DDDAN-T: 0.034797M/7.361742848G  | 0.043452M/4.150128128G  | 0.055569M/3.034830848G
DDDAN-S: 0.165202M/34.217177088G | 0.173857M/16.067232768G | 0.185974M/9.748697088G
DDDAN-M: 0.321688M/66.443698176G | 0.330343M/30.367758336G | 0.34246M/17.805336576G
DDDAN-L: 0.426012M/87.928045568G | 0.434667M/39.901442048G | 0.446784M/23.176429568G
'''
