# GENERATED VERSION FILE
# TIME: Mon Jan 15 19:23:44 2024
__version__ = '1.4.2'
__gitsha__ = 'unknown'
version_info = (1, 4, 2)
