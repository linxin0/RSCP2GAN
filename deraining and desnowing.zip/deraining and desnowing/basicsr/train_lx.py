import os
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
import argparse
import cv2
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm
from warmup_scheduler import GradualWarmupScheduler
import utils
import losses
import clip.clip
import os

img_path = '/media/sr617/29b9171f-dba6-4703-98a5-43495a4a4fe6/MPRNet-main/Denoising/DATA/test/blur'
targeet_path = '/media/sr617/29b9171f-dba6-4703-98a5-43495a4a4fe6/MPRNet-main/Denoising/DATA/test/test_noisy/target'

img_list = sorted(os.listdir(img_path))
num_img = len(img_list)


def print_args(args, cfg):
    print("***************")
    print("** Arguments **")
    print("***************")
    optkeys = list(args.__dict__.keys())
    optkeys.sort()
    for key in optkeys:
        print("{}: {}".format(key, args.__dict__[key]))
    print("************")
    print("** Config **")
    print("************")
    print(cfg)


def reset_cfg(cfg, args):
    if args.output_dir:
        cfg.OUTPUT_DIR = args.output_dir

    if args.resume:
        cfg.RESUME = args.resume

    if args.seed:
        cfg.SEED = args.seed

    if args.source_domains:
        cfg.DATASET.SOURCE_DOMAINS = args.source_domains

    if args.target_domains:
        cfg.DATASET.TARGET_DOMAINS = args.target_domains

    if args.transforms:
        cfg.INPUT.TRANSFORMS = args.transforms

    if args.trainer:
        cfg.TRAINER.NAME = args.trainer

    if args.backbone:
        cfg.MODEL.BACKBONE.NAME = args.backbone

    if args.head:
        cfg.MODEL.HEAD.NAME = args.head





def setup_cfg(args):
    cfg = get_cfg_default()

    # 2. From the method config file
    if args.config_file:
        cfg.merge_from_file(args.config_file)

        # 3. From input arguments
    reset_cfg(cfg, args)

    # 4. From optional input arguments
    cfg.merge_from_list(args.opts)

    cfg.freeze()

    return cfg


def load_clip_to_cpu(cfg):
    url = clip.clip._MODELS["RN50x16"]
    # url = clip.clip._MODELS["ViT-B/16"]
    model_path = clip.clip._download(url)

    try:
        # loading JIT archive
        model = torch.jit.load(model_path, map_location="cpu").eval()
        state_dict = None

    except RuntimeError:
        state_dict = torch.load(model_path, map_location="cpu")
    design_details = {"trainer": 'CoOp',
                      "vision_depth": 0,
                      "language_depth": 0, "vision_ctx": 0,
                      "language_ctx": 0}
    model = clip.clip.build_model(state_dict or model.state_dict(), design_details)

    return model


from data_RGB import get_training_data, get_validation_data
# from data_sige import get_training_data, get_validation_data

import time
from PIL import Image
from torchvision.transforms import transforms
import os
from torch.nn import functional as F
from NAFNet_arch import NAFNet
criterion = losses.CharbonnierLoss()
ide_loss = torch.nn.L1Loss()
clip_los = torch.nn.L1Loss()
L_clip = L_clip_from_feature()
import torch
import torchvision
import hyperIQA.models
from PIL import Image
import numpy as np


def pil_loader(path):
    with open(path, 'rb') as f:
        img = Image.open(f)
        return img.convert('RGB')


def main(args):
    cfg = setup_cfg(args)
    if cfg.SEED >= 0:
        print("Setting fixed seed: {}".format(cfg.SEED))
        set_random_seed(cfg.SEED)
    setup_logger(cfg.OUTPUT_DIR)
    train_dir = './DATA/input'
    train_dataset = get_training_data(train_dir, {'patch_size': args.PS})

    train_loader = DataLoader(dataset=train_dataset, batch_size=args.BS, shuffle=True, num_workers=16,
                              drop_last=False, pin_memory=True)

    if torch.cuda.is_available() and cfg.USE_CUDA:
        torch.backends.cudnn.benchmark = True

    print_args(args, cfg)
    print("Collecting env info ...")
    print("** System info **\n{}\n".format(collect_env_info()))

    # model_r = NAFNet()
    # model_r.cuda()

    # model_clip = build_trainer(cfg)
    classnames = ['blur', 'noisy', 'rainy']
    clip_model = load_clip_to_cpu(cfg)

    model_r = NAFNet()
    model_r.cuda()



    optim_r = torch.optim.Adam(model_r.parameters(), lr=1e-3, betas=(0.9, 0.9), eps=1e-8, weight_decay=0)
    warmup_epochs = 3

    # scheduler_cosine = torch.optim.lr_scheduler.CosineAnnealingLR(optim_r, 200,
    #                                                               eta_min=1e-5)
    # scheduler = GradualWarmupScheduler(optim_r, multiplier=1, total_epoch=warmup_epochs,
    #                                    after_scheduler=scheduler_cosine)
    # scheduler.step()

    model_hyper = hyperIQA.models.HyperNet(16, 112, 224, 112, 56, 28, 14, 7).cuda()
    model_hyper.train(False)
    # load our pre-trained model on the koniq-10k dataset
    model_hyper.load_state_dict((torch.load(
        "/media/sr617/29b9171f-dba6-4703-98a5-43495a4a4fe6/MPRNet-main/Denoising/hyperIQA/pretrained/koniq_pretrained.pkl")))

    # transforms = torchvision.transforms.Compose([
    #     torchvision.transforms.Resize((512, 384)),
    #     torchvision.transforms.RandomCrop(size=224),
    #     torchvision.transforms.ToTensor(),
    #     torchvision.transforms.Normalize(mean=(0.485, 0.456, 0.406),
    #                                      std=(0.229, 0.224, 0.225))])

    start_epoch = 1
    if args.resume:
        path_chk_rest = utils.get_last_path(args.model_dir, 'model_epoch_183.pth')

        # utils.load_checkpoint(model_r, path_chk_rest)
        # utils.load_checkpoint_c(model_c, path_chk_rest)
        utils.load_checkpoint_r(model_r, path_chk_rest)
        # print("xxxx")
        # start_epoch = 1
        start_epoch = utils.load_start_epoch(path_chk_rest) + 1
        # utils.load_optim(optimizer_r, path_chk_rest)
        # utils.load_optim_c(optim, path_chk_rest)
        utils.load_optim_r(optim_r, path_chk_rest)

        # for i in range(1, start_epoch):
        # scheduler_r.step()
        # scheduler_c.step()
        # new_lr = scheduler_r.get_lr()[0]
        # LOSS = 0
    for epoch in range(start_epoch, args.epoch + 1):
        epoch_start_time = time.time()
        epoch_loss = 0
        train_id = 1
        # model_r.train()
        #
        # for i, data in enumerate(tqdm(train_loader), 0):
        #
        #     target = data[0].cuda()
        #     input_ = data[1].cuda()
        #
        #
        #     out = model_r(input_)
        #     ide = ide_loss(out, target)
        #
        #     # iqa = np.float64(iqa)
        #     # iqa = torch.tensor(iqa)
        #     loss = ide
        #     # print(ide)
        #     # print(iqa)
        #     # print(iqa)
        #     # print(ide)
        #     optim_r.zero_grad()
        #
        #     loss.backward()
        #
        #     optim_r.step()
        #
        #     epoch_loss += ide.item()
        #     loss_out = epoch_loss / float(i + 1)
        #     # scheduler.step()
        #
        # print("------------------------------------------------------------------")
        # print("Epoch: {}\tTime: {:.4f}\tLoss: {:.4f}".format(epoch,
        #                                                      time.time() - epoch_start_time,
        #                                                      loss_out))
        # print("------------------------------------------------------------------")
        # # scheduler.step()
        # torch.save({'epoch': epoch,
        #             'state_dict_r': model_r.state_dict(),
        #             'optimizer_r': optim_r.state_dict()
        #             }, os.path.join(args.output_dir, f"model_epoch_{epoch}.pth"))
        # LOSS = LOSS / 750
        # print(LOSS)
        print("laileao")
        # model_c.eval()
        model_r.eval()
        #
        transform = transforms.ToTensor()
        PSNR = 0
        for img in img_list:
            image = Image.open(img_path + '/' + img).convert('RGB')
            target = Image.open(targeet_path + '/' + img).convert('RGB')
            image = transform(image)
            target = transform(target)
            image = image.cuda()
            target = target.cuda()

            [A, B, C] = image.shape
            image = image.reshape([1, A, B, C])
            [A, B, C] = target.shape
            target = target.reshape([1, A, B, C])
            save_path = './DATA/output'
            save_path_1 = save_path + '/' + img
            with torch.set_grad_enabled(False):
                pre = model_r(image)
                # pre = pre.squeeze(0).cpu().detach().numpy()
            #
            # prel = np.transpose(pre, axes=[1, 2, 0]).astype('float32')
            # prel = np.uint8(np.round(np.clip(prel, 0, 1) * 255.))[:, :, ::-1]
            # cv2.imwrite(save_path_1, prel)
            p_numpy = pre.squeeze(0).cpu().detach().numpy()
            label_numpy = target.squeeze(0).cpu().detach().numpy()

            psnr = peak_signal_noise_ratio(label_numpy, p_numpy, data_range=1)
            PSNR += psnr
        PSNR = PSNR / num_img
        print("PSNR =", PSNR)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--TRAIN_DIR", type=str, default="./Datasets/train", help="path to dataset")
    parser.add_argument("--PS", type=int, default=224, help="ps")
    parser.add_argument("--BS", type=int, default=16, help="path to dataset")
    parser.add_argument("--epoch", type=int, default=500, help="path to dataset")

    parser.add_argument("--output_dir", type=str, default="checkpoint_naf", help="output directory")
    parser.add_argument(
        "--resume",
        type=str,
        default="True",
        help="checkpoint directory (from which the training resumes)",
    )
    parser.add_argument(
        "--seed", type=int, default=-1, help="only positive value enables a fixed seed"
    )
    parser.add_argument(
        "--source-domains", type=str, nargs="+", help="source domains for DA/DG"
    )
    parser.add_argument(
        "--target-domains", type=str, nargs="+", help="target domains for DA/DG"
    )
    parser.add_argument(
        "--transforms", type=str, nargs="+", help="data augmentation methods"
    )
    parser.add_argument(
        "--config-file", type=str, default="configs/trainers/CoOp/rn50_ep100.yaml", help="path to config file"
    )
    parser.add_argument("--trainer", type=str, default="CoOp", help="name of trainer")
    parser.add_argument("--backbone", type=str, default="", help="name of CNN backbone")
    parser.add_argument("--head", type=str, default="", help="name of head")
    parser.add_argument("--eval-only", action="store_true", help="evaluation only")
    parser.add_argument(
        "--model-dir",
        type=str,
        default="checkpoint_naf",
        help="load model from this directory for eval-only mode",
    )
    parser.add_argument(
        "--load-epoch", type=int, help="load model weights at this epoch for evaluation"
    )
    parser.add_argument(
        "--no-train", action="store_true", help="do not call trainer.train()"
    )
    parser.add_argument(
        "opts",
        default=None,
        nargs=argparse.REMAINDER,
        help="modify config options using the command-line",
    )
    args = parser.parse_args()
    main(args)